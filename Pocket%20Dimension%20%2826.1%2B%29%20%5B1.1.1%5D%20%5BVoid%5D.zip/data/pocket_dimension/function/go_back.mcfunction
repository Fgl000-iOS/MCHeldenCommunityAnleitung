# say teleporting!
$execute on vehicle in $(Dimension) run tp @s $(px) $(py) $(pz) $(rx) $(ry)
$execute as @s[nbt={Dimension:"pocket_dimension:sky_islands"}] in $(Dimension) run tp @s $(px) $(py) $(pz) $(rx) $(ry)
$execute as @e[nbt={leash:{UUID:$(UUID)}}] at @a[nbt={UUID:$(UUID)}] run tp @s ~ ~0.5 ~
$execute as @e[nbt={Owner:{UUID:$(UUID)},Sitting:0b}] at @a[nbt={UUID:$(UUID)}] run tp @s ~ ~0.5 ~
$execute as @e[nbt={Owner:$(UUID),Sitting:0b},limit=20] at @a[nbt={UUID:$(UUID)}] run tp @s ~ ~0.5 ~
$data remove storage minecraft:pocket_dimension "$(UUID)"
playsound minecraft:block.beehive.exit ambient @s ~ ~ ~ 999 2