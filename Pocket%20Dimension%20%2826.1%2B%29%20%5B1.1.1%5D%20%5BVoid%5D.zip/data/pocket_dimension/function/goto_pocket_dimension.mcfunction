# say teleporting!
$data remove storage minecraft:pocket_dimension "$(UUID)"
schedule function pocket_dimension:use_check 6s replace
$data remove storage minecraft:pocket_dimension "$(UUID)"
$data merge storage minecraft:pocket_dimension {"$(UUID)":{UUID:$(UUID),Dimension:"$(Dimension)"}}

$data modify storage minecraft:pocket_dimension "$(UUID)".px set from entity @s Pos[0]
$data modify storage minecraft:pocket_dimension "$(UUID)".py set from entity @s Pos[1]
$data modify storage minecraft:pocket_dimension "$(UUID)".pz set from entity @s Pos[2]

$data modify storage minecraft:pocket_dimension "$(UUID)".rx set from entity @s Rotation[0]
$data modify storage minecraft:pocket_dimension "$(UUID)".ry set from entity @s Rotation[1]

execute in pocket_dimension:sky_islands run forceload add 0 0
execute in pocket_dimension:sky_islands run setblock 0 -64 0 minecraft:bedrock keep
execute in pocket_dimension:sky_islands run forceload add 0 0
execute in pocket_dimension:sky_islands positioned 0 0 0 positioned over motion_blocking_no_leaves on vehicle run tp @s ~ ~ ~ 0 0
execute in pocket_dimension:sky_islands positioned 0 0 0 positioned over motion_blocking_no_leaves if entity @s[nbt=!{Dimension:"pocket_dimension:sky_islands"}] run tp @s ~ ~ ~ 0 0
$execute as @e[nbt={leash:{UUID:$(UUID)}}] at @a[nbt={UUID:$(UUID)}] run tp @s ~ ~0.5 ~
$execute as @e[nbt={Owner:$(UUID),Sitting:0b},limit=20] at @a[nbt={UUID:$(UUID)}] run tp @s ~ ~0.5 ~
#execute in pocket_dimension:sky_islands run forceload remove 0 0

stopsound @s ambient minecraft:entity.zombie_villager.converted
playsound minecraft:block.large_amethyst_bud.break ambient @s ~ ~ ~ 999 2
