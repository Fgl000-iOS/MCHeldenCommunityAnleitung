tellraw @s "Your position was void, sending you to Overworld."
execute in minecraft:overworld run forceload add 0 0
execute in minecraft:overworld positioned 0 0 0 positioned over motion_blocking run tp @s ~ ~ ~
execute in minecraft:overworld run forceload remove 0 0
playsound minecraft:block.beehive.exit ambient @s ~ ~ ~ 999 2