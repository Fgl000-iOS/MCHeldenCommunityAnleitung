#say check
execute as @a[scores={pd_return=1..},nbt={Dimension:"pocket_dimension:sky_islands"}] run function pocket_dimension:portal_used with entity @s
execute as @a[scores={pocket_dimension_used=1..}] if items entity @s weapon.* minecraft:carrot_on_a_stick[minecraft:custom_data={pocket_dimension:1b}] run function pocket_dimension:portal_used with entity @s
#execute as @a[scores={pocket_dimension_used=1..}] if entity @s[nbt={Inventory:[{id:"minecraft:carrot_on_a_stick",components:{"minecraft:custom_data":{pocket_dimension:1b}}}]}] run function pocket_dimension:portal_used with entity @s
scoreboard players set @a[scores={pocket_dimension_used=1..}] pocket_dimension_used 0

execute as @a[nbt={Dimension:"pocket_dimension:sky_islands"}] run scoreboard players enable @s pd_return
execute as @a[nbt=!{Dimension:"pocket_dimension:sky_islands"}] run scoreboard players reset @s pd_return

schedule function pocket_dimension:use_check 5t replace