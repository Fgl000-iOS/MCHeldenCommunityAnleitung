#say used
execute as @s at @s run playsound minecraft:entity.zombie_villager.converted ambient @s ~ ~ ~ 999 1.5
function pocket_dimension:forceload

tag @s remove pocket_dimension
execute at @s if dimension pocket_dimension:sky_islands run tag @s add pocket_dimension

$execute as @a[nbt={UUID:$(UUID)}] if entity @s[tag=pocket_dimension] unless data storage pocket_dimension "$(UUID)" run function pocket_dimension:tp_failed
$execute as @a[nbt={UUID:$(UUID)}] if entity @s[tag=pocket_dimension] if data storage pocket_dimension "$(UUID)" run function pocket_dimension:go_back with storage minecraft:pocket_dimension "$(UUID)"
$execute as @a[nbt={UUID:$(UUID)}] unless entity @s[tag=pocket_dimension] run function pocket_dimension:goto_pocket_dimension with entity @s

tag @s remove pocket_dimension