function pocket_dimension:forceload
scoreboard objectives remove pd_return
scoreboard objectives add pd_return trigger

scoreboard objectives remove pocket_dimension_used
scoreboard objectives add pocket_dimension_used minecraft.used:minecraft.carrot_on_a_stick
schedule function pocket_dimension:use_check 20t replace